$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/java/com/qa/feature/HomePage.feature");
formatter.feature({
  "name": "Verification of HomePage",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "verify title",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "User is in HomePages",
  "keyword": "Given "
});
formatter.match({
  "location": "com.qa.stepdefn.StepDefn.user_is_in_HomePages()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "verify title of page",
  "keyword": "Then "
});
formatter.match({
  "location": "com.qa.stepdefn.StepDefn.verify_title_of_page()"
});
formatter.result({
  "status": "passed"
});
});