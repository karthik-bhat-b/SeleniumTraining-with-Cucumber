package com.qa.stepdefn;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class StepDefn {
	WebDriver driver;
	@Given("User is in HomePages")
	public void user_is_in_HomePages() {
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.get("https://www.amazon.com/");
	
	}

	@Then("verify title of page")
	public void verify_title_of_page() {

		System.out.println(driver.getTitle());
	}
}
