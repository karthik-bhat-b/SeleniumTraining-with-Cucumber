package sap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LaunchAndCloseBrowser {
	public WebDriver driver;
	@BeforeTest
	public void open() {
		WebDriverManager.firefoxdriver().setup();
		driver=new FirefoxDriver();
//		WebDriverManager.chromedriver().setup();
//		driver=new ChromeDriver();
	}
	@Test
	public void Maven_Test() {
		driver.get("http://softest-training.com");
		System.out.println(driver.getTitle());
	}
	
	@AfterTest
	public void close() {
		driver.quit();
	}
}
