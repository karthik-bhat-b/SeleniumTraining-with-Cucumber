package day6;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class ExampleJS extends OpenCloseBrowser{
@Test
public void test() throws Exception {
	
	openHome("https://www.youtube.com");
	List <WebElement> videos=driver.findElements(By.cssSelector("ytd-rich-item-renderer"));
	System.out.println(videos.size());
	
	JavascriptExecutor js= (JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,5000)");
	Thread.sleep(2000);
	videos=driver.findElements(By.cssSelector("ytd-rich-item-renderer"));
	System.out.println(videos.size());
	
}
}
