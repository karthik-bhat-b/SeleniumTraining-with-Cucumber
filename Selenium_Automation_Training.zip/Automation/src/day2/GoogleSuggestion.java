package day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class GoogleSuggestion extends OpenCloseBrowser{

	@Test
	public void countSuggestions() {
		openHome("http://google.com");
		String s="Heloo";
		driver.findElement(By.name("q")).sendKeys(s);
		List<WebElement> suggestions =driver.findElements(By.xpath("//ul[@role='listbox']//li//span"));
		for(WebElement sug:suggestions) {
			System.out.println(sug.getText());
		}
	}
}
