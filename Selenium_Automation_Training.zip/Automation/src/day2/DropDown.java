package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class DropDown extends OpenCloseBrowser{
@Test
public void select1() {
	openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1501486869DropDown.html");
	WebElement drop1=driver.findElement(By.id("Drop01"));
	Select s1=new Select(drop1);
	s1.selectByVisibleText("Business");
	System.out.println(drop1.getAttribute("value"));
}
@Test
public void select2() {
	openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1501486869DropDown.html");
	WebElement drop2=driver.findElement(By.id("Drop02"));
	Select s2=new Select(drop2);
	s2.selectByValue("Bus");
	s2.selectByIndex(2);
	s2.selectByVisibleText("Taxi");
	
	System.out.println();
}
}
