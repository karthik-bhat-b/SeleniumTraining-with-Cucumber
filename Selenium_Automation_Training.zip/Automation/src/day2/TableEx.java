package day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class TableEx extends OpenCloseBrowser{
@Test
public void tc_Table01() {
openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1407405934WebTable.html");
WebElement tb= driver.findElement(By.xpath("//table[@id='table1']//tbody"));
List <WebElement> ls=tb.findElements(By.tagName("tr"));
for(WebElement row :ls) {
	List <WebElement> col= row.findElements(By.tagName("td"));
	for(WebElement c:col) {
		if(c.getText().equals("LoadRunner")) {
			System.out.println("Row: "+ls.indexOf(row));
			row.findElement(By.xpath("//td/a[text()='EDIT']")).click();
			System.out.println(driver.getCurrentUrl());
		}
	}
}
}
}
