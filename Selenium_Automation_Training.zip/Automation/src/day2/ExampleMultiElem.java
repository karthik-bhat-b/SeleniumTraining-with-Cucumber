package day2;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;
public class ExampleMultiElem extends OpenCloseBrowser{

	@Test
	public void findAnchourTags() {
		openHome("http://softest-training.com/");
		List <WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(WebElement link:links) {
			System.out.println("Link href: "+link.getAttribute("href"));
		}
	}
	@Test
	public void xcountClientLogs() {
		openHome("http://softest-training.com/");
		driver.findElement(By.xpath("//div[@id='fotter']//a[6]")).click();
		List <WebElement> links=driver.findElements(By.cssSelector("td.deti img"));
		System.out.println("No.of user logos:"+links.size());
	}
}
