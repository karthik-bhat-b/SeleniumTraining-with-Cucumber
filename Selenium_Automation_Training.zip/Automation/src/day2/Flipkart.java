package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class Flipkart extends OpenCloseBrowser{
@Test
public void search() {
	openHome("https://www.snapdeal.com/");
	Actions act=new Actions(driver);
	act.moveToElement(driver.findElement(By.cssSelector("div.accountInner")));
	driver.findElement(By.xpath(""));
}
}
