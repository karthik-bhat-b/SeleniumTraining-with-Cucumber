package day2;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import day1.OpenCloseBrowser;
public class PaswordCh extends OpenCloseBrowser{
	
@Test(dataProvider="dp",dataProviderClass=MyDps.class)
public void login(String x,String y) throws Exception {
	openHome("http://softest-training.com/");
	driver.findElement(By.xpath("//div[@class='navigation']//li[8]")).click();
	Thread.sleep(1000);
	driver.findElement(By.name("username")).sendKeys(x);
	driver.findElement(By.name("password")).sendKeys(y);
	Thread.sleep(1000);
	driver.findElement(By.id("submit")).click();
	driver.findElement(By.xpath("//a[@class='text12']")).click();
	
}
}
