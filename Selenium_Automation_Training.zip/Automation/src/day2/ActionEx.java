package day2;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class ActionEx extends OpenCloseBrowser{
	@Test(enabled=false)
	public void Move() {
		openHome("https://www.naukri.com/");
		WebElement jobs=driver.findElement(By.className("mTxt"));
		Actions act=new Actions(driver);
		act.moveToElement(jobs).perform();
		driver.findElement(By.linkText("Jobs by Skill")).click();
	}
	@Test(enabled=false)
	public void copypaste() throws InterruptedException {
		openHome("http://google.com");
		WebElement searchBox=driver.findElement(By.name("q"));
		searchBox.sendKeys("Sapient Test");
		Actions act = new Actions(driver);
		act.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();
		Thread.sleep(1000);
		act.keyDown(Keys.CONTROL).sendKeys("c").keyUp(Keys.CONTROL).perform();
		Thread.sleep(1000);
		searchBox.clear();
		searchBox.click();
		act.keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).perform();
		
	}
	@Test
	public void saveimg() throws Exception {
		openHome("https://www.publicissapient.com/");
		WebElement logo=driver.findElement(By.cssSelector(".logo a"));
		
		Actions act=new Actions(driver);
		act.contextClick(logo).perform();
		Thread.sleep(1000);
		Robot rb=new Robot();
	    rb.keyPress(KeyEvent.VK_V);
		rb.keyRelease(KeyEvent.VK_V);
		Thread.sleep(6000);
		rb.keyPress(KeyEvent.VK_ENTER);
		
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
	}
}
