package day2;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExDDT {
       
       @Test
       public void readFromExcel() throws Exception
       {
              String xlFile = "TestData/Testingdatademo.xlsx";
              FileInputStream fileIn = new FileInputStream(xlFile);
              XSSFWorkbook wb = new XSSFWorkbook(fileIn);
              XSSFSheet ws = wb.getSheetAt(0);
              int rc = ws.getLastRowNum()+1;
              System.out.println("Row count: "+rc);
              int cc = ws.getRow(0).getLastCellNum();
              System.out.println("Column count: "+cc);
              
              for(int i=1;i<rc;i++)
              {
                     XSSFRow row = ws.getRow(i);
                     for(int j=0;j<cc;j++)
                     {
                           XSSFCell cell = row.getCell(j);
                           String cellValue = cell.getStringCellValue();
                           System.out.println(cellValue);
                     }
              }
       }

}

