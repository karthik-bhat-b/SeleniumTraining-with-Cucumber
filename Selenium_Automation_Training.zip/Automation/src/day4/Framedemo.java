package day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class Framedemo extends OpenCloseBrowser{
@Test
public void test() {
	openHome("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_iframe");
	WebElement outerIframe=driver.findElement(By.id("iframeResult"));
	
	driver.switchTo().frame(outerIframe);
	WebElement frameInner=driver.findElement(By.tagName("iframe"));
	driver.switchTo().frame(frameInner);
	driver.findElement(By.linkText("LEARN HTML")).click();
	System.out.println(driver.findElement(By.cssSelector("div#main>h1")).getText());
	driver.switchTo().defaultContent();
}
}
