
package day4;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class AutoItDemo extends OpenCloseBrowser {
       
       @Test
       public void TC_SaveLogo() throws Exception
       {
              String autoItFile = "AutoItScript/DownloadLogo.exe";
              String imagFilePath = "Downloads/logo.svg";
              File file=new File(imagFilePath);
              if(file.exists()) {
                     file.delete();
              }
              openHome("https://www.publicissapient.com");
              WebElement logo=driver.findElement(By.cssSelector(".logo a"));
              
              Actions act = new Actions(driver);
              act.contextClick(logo).perform();
              Thread.sleep(1000);
              Process process=Runtime.getRuntime().exec(autoItFile);
              process.waitFor();
              Thread.sleep(5000);
       }
}
