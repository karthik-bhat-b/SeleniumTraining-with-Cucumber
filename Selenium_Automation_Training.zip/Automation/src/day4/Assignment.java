package day4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class Assignment extends OpenCloseBrowser{
@Test(enabled = true)
public void test1() throws Exception {
	openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1521781750IframeExample.html");
	Thread.sleep(2000);
	WebElement topframe=driver.findElement(By.id("Frame1"));//
	driver.switchTo().frame(topframe);
	WebElement innerTop=driver.findElement(By.xpath("//div[@id='top']//iframe"));
	driver.switchTo().frame(innerTop);
	System.out.println(driver.findElement(By.xpath("//button/div//span[3]")).getText());
}

@Test(enabled=true)
void testLogin() throws Exception {
	openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1521781750IframeExample.html");
	WebElement topframe=driver.findElement(By.id("Frame1"));//
	driver.switchTo().frame(topframe);
	driver.findElement(By.linkText("Login")).click();
	Thread.sleep(1000);
	driver.findElement(By.name("username")).sendKeys("user");
	driver.findElement(By.name("password")).sendKeys("pass");
	Thread.sleep(1000);
	driver.findElement(By.id("submit")).click();
	driver.findElement(By.xpath("//a[@class='text12']")).click();
}

@Test
void testLogo() {
	openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1521781750IframeExample.html");
	WebElement topframe=driver.findElement(By.id("Frame1"));
	driver.switchTo().frame(topframe);
	WebElement bottomframe=driver.findElement(By.xpath("//div[@id='Clients_']//iframe"));
	driver.switchTo().frame(bottomframe);
	List <WebElement> logos= driver.findElements(By.xpath("//td[@id='demo1']/table[@id='scroll_logo']//img"));//There are two elements with id 'scroll_logo'
	System.out.println(logos.size());

}
}
