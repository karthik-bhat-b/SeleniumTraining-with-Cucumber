package day4;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class JsAlert extends OpenCloseBrowser {
	Alert a;
	@Test
	public void alertCheck() {
		openHome("file:///C:/Users/karb1/Downloads/Selenium%20training/1400575597popup.html");
		driver.findElement(By.cssSelector("input[value='Show Alert Box']")).click();
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			a=driver.switchTo().alert();
			System.out.println("alert popped");
			a.accept();
			System.out.println(driver.findElement(By.id("result")).getText());
		}
		catch(Exception e) {
			System.out.println("No alert()");
		}
		
		
		driver.findElement(By.cssSelector("input[value='Show Confirm Box']")).click();
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			a=driver.switchTo().alert();
			System.out.println("Confirm popped");
			a.dismiss();
			System.out.println(driver.findElement(By.id("result")).getText());
		}
		catch(Exception e) {
			System.out.println("No Confirm alert()");
		}
		
		driver.findElement(By.cssSelector("input[value='Show Prompt Box']")).click();
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			a=driver.switchTo().alert();
			System.out.println("Prompt box popped");
			a.sendKeys("Ho ho ho ho hoh oh hohhho");
			a.accept();
			System.out.println(driver.findElement(By.id("result")).getText());
		}
		catch(Exception e) {
			System.out.println("No alert()");
		}
		}
}
