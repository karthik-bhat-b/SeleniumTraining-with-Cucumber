package day4;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class IrctcTest extends OpenCloseBrowser {
	Set <String> winHandles;
	@Test
	public void openTabs() throws Exception {
		openHome("https://www.irctc.co.in/");
		Thread.sleep(2000);
		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(By.linkText("STAYS"))).perform();
		driver.findElement(By.partialLinkText("Retiring Room")).click();
		act.moveToElement(driver.findElement(By.linkText("MEALS"))).perform();
		driver.findElement(By.linkText("E-Catering")).click();
		act.moveToElement(driver.findElement(By.linkText("AT STATIONS"))).perform();
		driver.findElement(By.linkText("E-wheelchair")).click();
		wait.until(ExpectedConditions.numberOfWindowsToBe(4));
		winHandles=driver.getWindowHandles();
		
		
	}
	@Test
	public void testRtRoom() {
		for(String wh:winHandles) {
			driver.switchTo().window(wh);
			if(driver.getCurrentUrl().contains("ACBooklogin")) {
				Assert.assertTrue(driver.findElement(By.linkText("Login")).isDisplayed());
				break;
			}
		}
	}
	@Test
	public void testFood() {
		for(String wh:winHandles) {
			driver.switchTo().window(wh);
			if(driver.getCurrentUrl().contains("ecatering")) {
				WebElement wc=driver.findElement(By.xpath("//div[@id='app']/div//section[4]//img[1]"));
				Assert.assertTrue(wc.getAttribute("src").contains("dominos"));
			}
		}
	}
	@Test
	public void testPnr() {
		for(String wh:winHandles) {
			driver.switchTo().window(wh);
			if(driver.getCurrentUrl().contains("wheelchair")) {
				WebElement wc=driver.findElement(By.xpath("//input[@name='pnrNo']"));
				Assert.assertTrue(wc.isDisplayed());
			}
		}
	}

}
