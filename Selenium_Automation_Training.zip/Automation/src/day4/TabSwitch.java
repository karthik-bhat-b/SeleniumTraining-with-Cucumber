package day4;

import java.util.Set;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.Test;

import day1.OpenCloseBrowser;

public class TabSwitch extends OpenCloseBrowser {
@Test
public void test1() {
	openHome("https://www.naukri.com/");
	
	wait.until(ExpectedConditions.numberOfWindowsToBe(3));
	String pwh=driver.getWindowHandle();
	Set <String> winHandles=driver.getWindowHandles();
	
	for(String wh:winHandles) {
		driver.switchTo().window(wh);
		System.out.println(driver.getTitle());
		if(!wh.equalsIgnoreCase(pwh))
		driver.close();
	}
	driver.switchTo().window(pwh);
}
}
