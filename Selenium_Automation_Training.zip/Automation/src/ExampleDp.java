import org.testng.annotations.Test;
import day2.MyDps;

public class ExampleDp {
	
	@Test(dataProvider="dp",dataProviderClass=MyDps.class)
	public void readDp(String x,String y,String z) {
		System.out.println("NAMe"+x);
		System.out.println("test name"+y);
		System.out.println("type"+z);
		
	}
}
