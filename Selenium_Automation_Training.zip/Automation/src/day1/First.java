package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class First {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver d;
		String url="http://google.com",title,fn;
		fn="C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", fn);
		
		d=new ChromeDriver();
		d.manage().window().maximize();
		d.get(url);
		WebElement searchBox=d.findElement(By.name("q"));
		searchBox.sendKeys("Selenium");
		Thread.sleep(1000);
		d.findElement(By.name("btnK")).click();
		System.out.println(d.getTitle());
		d.findElement(By.xpath("//div[@id='rso']//h3")).click();
		System.out.println(d.getTitle());
	}

}
