package day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class OpenCloseBrowser {

       public WebDriver driver;
       public String fn,title,url;
       public WebDriverWait wait;
       
       @BeforeTest
       public void openBrowserChrome()
       {
    	   
    	   String fn="C:\Users\karb1\Downloads\Selenium training\geckodriver-v0.26.0-win64\geckodriver.exe";
           System.setProperty("webdriver.chrome.driver", fn);
           driver=new ChromeDriver();
           driver.manage().window().maximize();
           driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           wait=new WebDriverWait(driver,20);
       }
       
       @BeforeTest(enabled=false)
       public void openBrowserFirefox()
       {
              fn="C:\\Users\\anah\\Desktop\\Selenium\\geckodriver.exe";
           System.setProperty("webdriver.gecko.driver", fn);
           driver=new FirefoxDriver();
           driver.manage().window().maximize();
       }
       public void openHome(String url)
       {
              driver.get(url);
              title=driver.getTitle();
              System.out.println("Homepage title is: "+title);
       }
//       @AfterTest
//       public void closeBrowser()
//       {
//              driver.quit();
//       }

       
       
       
}
