package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Kayak extends OpenCloseBrowser {
@Test
public void testUrl() {
	openHome("http://kayak.com");
	Assert.assertTrue(driver.getCurrentUrl().contains("https://www.kayak.co.in/"));
	
}
@Test
public void testField(){
	openHome("http://kayak.com");
	WebElement e=driver.findElement(By.xpath("//span[@class='redirect-banner']")); //div[@id='Lmax']/span 
	Assert.assertTrue(e.getText().contains("redirected to KAYAK.co.in"));
}

@Test 
public void testCloseBannerButton() {
	openHome("http://kayak.com");
	WebElement e=driver.findElement(By.xpath("//div[@id='Lmax']//button"));
	e.click();
}
}
