package day1;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGDemo {

@BeforeTest
public void bt() {
	System.out.println("Before Test");
}
@BeforeClass
public void bc() {
	System.out.println("Before Class");
}
@BeforeMethod
public void bm() {
	System.out.println("Before Method");
}
@Test(priority=3)
public void tc03() {
	System.out.println("Test 03");
}
@Test(dependsOnMethods="tc02",priority=2)
public void tc01() {
	System.out.println("Test 01");
}
@Test(priority=1)
public void tc02() {
	System.out.println("Test 02");
	Assert.assertTrue(true);
}
@AfterMethod
public void am() {
	System.out.println("After Method");
}
@AfterTest
public void at() {
	System.out.println("After Test");
}
}

