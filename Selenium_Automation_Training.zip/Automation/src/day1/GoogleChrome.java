package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class GoogleChrome {
	WebDriver d;
	public GoogleChrome() {
		String fn="C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", fn);
		d=new ChromeDriver();
		d.manage().window().maximize();
	}
	public void googleSearch(String key) throws InterruptedException {
		WebElement searchBox=d.findElement(By.name("q"));
		searchBox.sendKeys(key);
		Thread.sleep(1000);
		d.findElement(By.name("btnK")).click();
		System.out.println(d.getTitle());
		
	}
	public void openGoogle() {
		d.get("http://google.com");
	}
}

