package day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ExampleAssert {
	WebDriver d;
	String url="https://www.google.com/";
	public WebDriverWait wait;
@BeforeTest
public void openBrowser() {
	String fn="C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver_win32\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", fn);
	d=new ChromeDriver();
	d.manage().window().maximize();
	d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	wait= new WebDriverWait(d,20);
	d.get(url);
}

@Test
public void test() {
	Assert.assertEquals(d.getTitle(), "Google");
	System.out.println("Pass");
}
@Test
public void verifyLogo() {
	WebElement logo=d.findElement(By.id("hplogo"));
	Assert.assertTrue(logo.isDisplayed());
	System.out.println("Pass");
}
@Test(enabled=true)
public void verifyGmail() {
	WebElement gmail=d.findElement(By.linkText("Gmail"));
	Assert.assertTrue(gmail.getAttribute("href").contains("mail.google.com"));
}
}
