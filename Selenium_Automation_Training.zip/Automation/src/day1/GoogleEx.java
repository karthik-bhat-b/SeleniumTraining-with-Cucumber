package day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoogleEx {
	WebDriver d;
	String url="http://google.com";
	public WebDriverWait wait;
@BeforeTest
public void openBrowser() {
	String fn="C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver_win32\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", fn);
	d=new ChromeDriver();
	d.manage().window().maximize();
	
	d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	wait= new WebDriverWait(d,20);
}
@Test
public void googleSearch() throws InterruptedException {
	d.get(url);
	wait.until(ExpectedConditions.titleContains("Google")); //Explicit wait
	WebElement searchBox=d.findElement(By.name("q"));
	searchBox.sendKeys("Selenium");
	//searchBox.sendKeys(Keys.ENTER);
	//Thread.sleep(1000);
	WebElement btn= d.findElement(By.name("btnK"));
	wait.until(ExpectedConditions.elementToBeClickable(btn));
	btn.click();
	System.out.println(d.getTitle());
	d.findElement(By.xpath("//div[@id='rso']//h3")).click();
	System.out.println(d.getTitle());
}
@AfterTest
public void closeBrowser() {
	d.quit();
}
}
