package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ExampleVerify extends OpenCloseBrowser {

       @Test(enabled=false)
       public void verifyLogo()
       {
              openHome("https://www.google.com");
              WebElement logo=driver.findElement(By.id("hplogo"));
              Assert.assertTrue(logo.isDisplayed());
              System.out.println("SRC is : "+logo.getAttribute("src"));
              System.out.println("alt is : "+logo.getAttribute("alt"));
              System.out.println("Test passed");
       }
       
       @Test(enabled=true)
       public void verifyGmail()
       {
              openHome("https://www.google.com");
              WebElement gmail=driver.findElement(By.linkText("Gmail"));
              String href=gmail.getAttribute("href");
              Assert.assertTrue(href.contains("mail.google.com"));
              System.out.println("pass");
       }
}
