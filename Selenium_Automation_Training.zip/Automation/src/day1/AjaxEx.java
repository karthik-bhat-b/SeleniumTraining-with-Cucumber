package day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AjaxEx {
	WebDriver d;
	String url="https://www.w3schools.com/xml/ajax_intro.asp";
	public WebDriverWait wait;
@BeforeTest
public void openBrowser() {
	String fn="C:\\Users\\karb1\\Downloads\\Selenium training\\chromedriver_win32\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", fn);
	d=new ChromeDriver();
	d.manage().window().maximize();
	d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	wait= new WebDriverWait(d,20);
}
@Test
public void ajaxTest() {
	d.get(url);
	WebElement ajaxelem=d.findElement(By.id("demo"));
	System.out.println("Before: "+ajaxelem.getText());
	d.findElement(By.xpath("//div[@id='demo']/button")).click();
	wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(ajaxelem, "Let AJAX change this text")));
	System.out.println(ajaxelem.getText());
}
}
