package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenCloseBrowser {
 public WebDriver driver;
 
 public WebDriverWait wait;
 @BeforeTest
 public void openBrowser() {
	 WebDriverManager.firefoxdriver().setup();
		driver=new FirefoxDriver();
 }
 public void OpenHomePage()	{
//		driver.get(config.getApplicationUrl());
		driver.get("http://softest-training.com/");
		Reporter.log("Home Title : " + driver.getTitle(),true);
	}
 
 @AfterTest
	public void CloseBrowser()
	{
	//	driver.close();
		driver.quit();
		
	}
}
