package Test;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.MyDataProvider;
import com.OpenCloseBrowser;

import pages.Home;
import pages.Login;
import pages.Profile;

public class MainTest extends OpenCloseBrowser{
	Home home;
	Login login;
	Profile profile;
	@BeforeMethod
	public void initElem()
	{
		 home = PageFactory.initElements(driver, Home.class);
		 login= PageFactory.initElements(driver, Login.class);
		 profile= PageFactory.initElements(driver, Profile.class);
	}
	@Test(dataProvider="Softest",dataProviderClass=MyDataProvider.class)
	public void testLogin(String u,String p) throws Exception
	{
		//home.HomePage().enterSearchKey(searchKey).clickSearchButton().clickFirstSuggestion();
		OpenHomePage();
		login.enterUname(u);
		Thread.sleep(1000);
		login.enterPass(p).click_submit();
		Thread.sleep(1000);
		
	}

}
