package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Profile{

private WebDriver driver;
@CacheLookup
@FindBy(how = How.CLASS_NAME ,using = "text12")
public WebElement logout;

public Profile(WebDriver driver) {
	this.driver=driver;
}

public Home signout() {
logout.click();
return new Home(driver);	
}
}
