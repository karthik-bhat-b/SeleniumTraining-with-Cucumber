package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Login{
	
	private WebDriver driver;
	@CacheLookup
	@FindBy(how = How.ID ,using = "textfield")
	public WebElement uname;
	@FindBy(how = How.ID ,using = "textfield2")
	public WebElement pass;
	
	@FindBy(how = How.ID ,using = "submit")
	public WebElement submit;
	
	
	public Login(WebDriver driver) {
		this.driver=driver;
	}

	public Login enterUname(String u) {
	uname.sendKeys(u);
	return this;
	}

	public Login enterPass(String p) {
	pass.sendKeys(p);
	return this;
	}

public Profile click_submit() {
	submit.click();
	return new Profile(driver);
}
}
