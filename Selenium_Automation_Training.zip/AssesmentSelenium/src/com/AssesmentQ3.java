//Count the leaves
package com;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AssesmentQ3 {
	public WebDriver driver;
	public String fn,title,url;
	public WebDriverWait wait;
	
	String uname=""; //<---------Enter UserName
	String pass=""; //<----------Enter Password
	
	ReadConfig config;
	@BeforeTest
	public void openTimetracking() throws Exception
	{
		config=new ReadConfig();
		System.setProperty("webdriver.chrome.driver", config.getChromeDriverPath());
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	   driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	   wait=new WebDriverWait(driver,config.getExplicitWait());  
	   driver.get("https://timetracking.sapient.com/");
	   title=driver.getTitle();
	   System.out.println("Homepage title is: "+title);
	   Thread.sleep(1000);
		driver.findElement(By.id("userNameInput")).sendKeys(uname);
		driver.findElement(By.id("passwordInput")).sendKeys(pass);
		Thread.sleep(1000);
		driver.findElement(By.id("submitButton")).click();
		Thread.sleep(1000);
	}
	@Test
	public void go_vacationTracker() throws Exception {
		driver.findElement(By.linkText("Vacation Tracker")).click();
		Thread.sleep(5000);
		System.out.println("Priviliaged Leave PL="+driver.findElement(By.id("MainContent_MainContent_LeftContent_dlIntern_lblIndiaVacationBalance")).getText());
		System.out.println("Public Holiday PH="+driver.findElement(By.id("MainContent_MainContent_LeftContent_dlIntern_lblNewPublicVacBal")).getText());
		System.out.println("Comp Holiday CD="+driver.findElement(By.id("MainContent_MainContent_LeftContent_dlIntern_lblNewCompBal")).getText());
		
	}
	@AfterTest
	public void closeBrowser()
	{
	driver.quit();
	}
}
