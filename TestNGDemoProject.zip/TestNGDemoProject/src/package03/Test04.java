package package03;


import org.testng.annotations.Test;

public class Test04 
{
	@Test(groups="Regression")
	public void Case1()
	{
		System.out.println("package03-- Test04 -- case01==regress");
	}

	@Test(groups="Sanity")
	public void Case2()
	{
		System.out.println("package03-- Test04 -- case02==sanity");
	}
}
