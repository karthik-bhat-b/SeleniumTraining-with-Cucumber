package package03;



import org.testng.Assert;
import org.testng.annotations.Test;

public class Test05 
{
	@Test(groups="Sanity")
	public void Case1()
	{
		System.out.println("package03-- Test05 -- case01==sanity");
	}
	@Test(groups="Regression")
	public void Case2()
	{
		System.out.println("package03-- Test05 -- case02==regress");
		//Assert.assertEquals("a", "b");
	}
	@Test(groups="Regression")
	public void Case3()
	{
		System.out.println("package03-- Test05 -- case03==regress");
	}
	@Test(groups="Sanity")
	public void Case4()
	{
		System.out.println("package03-- Test05 -- case04==sanity");
	}
	@Test(groups="Sanity")
	public void Case5()
	{
		System.out.println("package03-- Test05 -- case05==sanity");
	}

}
