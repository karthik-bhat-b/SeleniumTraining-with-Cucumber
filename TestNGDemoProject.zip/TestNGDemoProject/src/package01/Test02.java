package package01;


import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class Test02 
{

	@Test(groups="Regression")
	public void Case1()
	{
		System.out.println("package01-- Test02 -- case01==regress");
	}
	
	
	@Test(groups="Regression")
	public void Case2()
	{
		System.out.println("package01-- Test02 -- case02==regress");
	}
	
	@Test(groups="Sanity")
	public void Case3()
	{
		System.out.println("package01-- Test02 -- case3==sanity");
	}
}
