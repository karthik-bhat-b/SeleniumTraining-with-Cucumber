package package01;

import org.testng.annotations.Test;

public class Test01 
{
	@Test(groups="Regression",description="Case-1")
	public void Case1()
	{
		System.out.println("package01--Test01 --case01--- regress");
		
	}

	@Test(groups="Sanity")
	public void Case2()
	{
		System.out.println("package01--Test01 -- case02--- sanity");
	}
	
	
	
	
}
