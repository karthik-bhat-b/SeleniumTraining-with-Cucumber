package packageParallel;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import packCommon.ReadConfiguration;

public class OpenCloseBrowserWithParameter
{
	public WebDriver driver;
	public String fn;
	public WebDriverWait wait;
	
	ReadConfiguration config;
	
	
	@Parameters("browser")
	@BeforeTest
	public void OpenBrowser(String browser)	{
		config=new ReadConfiguration();
		if(browser.equalsIgnoreCase("ff"))		{
			
			System.setProperty("webdriver.gecko.driver", config.getGeckoDriverPath());
			driver=new FirefoxDriver();			
		}
		else if(browser.equalsIgnoreCase("ie"))		{
			
			System.setProperty("webdriver.ie.driver", config.getIEDriverPath());
			driver=new InternetExplorerDriver();
		}
		else if(browser.equalsIgnoreCase("ch")) {
			System.setProperty("webdriver.chrome.driver", config.getChromeDriverPath());
			driver=new ChromeDriver();
		}
		else		{
			System.out.println("No browser defined");
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(config.getImplicitlyWait(), TimeUnit.SECONDS);
		wait=new WebDriverWait(driver,config.getExplicitWait());
	}
	public void OpenHomePage(String url)	{
		driver.get(url);
		Reporter.log("Home Title : " + driver.getTitle(),true);
	}
	@AfterTest
	public void CloseBrowser()	{
		driver.quit();
	}
	
}
