package packageParallel;

import org.testng.annotations.Test;

public class Parallel03 extends OpenCloseBrowserWithParameter
{
	@Test()
	public void TC_Linkedin()
	{
		OpenHomePage("http://linkedin.com");
		
	}

}
