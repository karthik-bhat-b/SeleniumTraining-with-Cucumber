package packageParallel;
import org.testng.Assert;
import org.testng.annotations.Test;


public class Parallel01 extends OpenCloseBrowserWithParameter

{
	@Test
	public void TC_Google()
	{
		OpenHomePage("http://google.com");
	}

}
