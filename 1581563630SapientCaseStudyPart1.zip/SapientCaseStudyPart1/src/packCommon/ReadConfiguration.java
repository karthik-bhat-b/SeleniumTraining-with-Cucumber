package packCommon;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadConfiguration 
{
	private Properties properties;
	private final String propertyFilePath= "Data/config.properties";
	
		public ReadConfiguration()
		{
			 FileInputStream reader;
			 try 
			 {
				 reader=new FileInputStream(propertyFilePath);
				 properties = new Properties();
				 try 
				 {
					 properties.load(reader);
					 reader.close();
				 } 
				 catch (IOException e)
				 {
					 e.printStackTrace();
				 }
			 } 
			 catch (FileNotFoundException e) 
			 {
				 e.printStackTrace();
				 throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
			 } 		 
		}	
		
		public String getDriverPath()
		{
			 String driverPath = properties.getProperty("driverPath");
			 if(driverPath!= null) return driverPath;
			 else throw new RuntimeException("driverPath not specified in the Configuration.properties file."); 
			 }
			 
			 public long getImplicitlyWait() { 
			 String implicitlyWait = properties.getProperty("implicitlyWait");
			 if(implicitlyWait != null) return Long.parseLong(implicitlyWait);
			 else throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file."); 
			 }
			 
			 public long getExplicitWait() { 
				 String explicitWait = properties.getProperty("explicitWait");
				 if(explicitWait != null) return Long.parseLong(explicitWait);
				 else throw new RuntimeException("explicitWait not specified in the Configuration.properties file."); 
				 }
			 
			 public String getApplicationUrl() {
			 String url = properties.getProperty("url");
			 if(url != null) return url;
			 else throw new RuntimeException("url not specified in the Configuration.properties file.");
			 }		
			 
			 public String getExcelPath()
				{
					 String excelFilePath = properties.getProperty("excelFilePath");
					 if(excelFilePath!= null) return excelFilePath;
					 else throw new RuntimeException("excelFilePath not specified in the Configuration.properties file."); 
					 }
			 
			 public int getexcelSheetIndex() { 
				 String excelSheetIndex = properties.getProperty("excelSheetIndex");
				 if(excelSheetIndex != null) return Integer.parseInt(excelSheetIndex);
				 else throw new RuntimeException("excelSheetIndex not specified in the Configuration.properties file."); 
				 }
			 
	}


