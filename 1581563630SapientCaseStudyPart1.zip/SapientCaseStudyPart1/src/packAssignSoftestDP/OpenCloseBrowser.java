package packAssignSoftestDP;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import packCommon.ReadConfiguration;

public class OpenCloseBrowser 
{
	public WebDriver driver;
	public String fn;
	public WebDriverWait wait;
	
	ReadConfiguration config;
	
	
	@BeforeTest
	public void OpenBrowserChrome()	{
		config=new ReadConfiguration();
		fn="C:\\SeleniumSetup\\chromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", config.getDriverPath());
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(config.getImplicitlyWait(), TimeUnit.SECONDS);
		wait=new WebDriverWait(driver,config.getExplicitWait());
	}
	public void OpenHomePage()	{
		driver.get(config.getApplicationUrl());
		Reporter.log("Home Title : " + driver.getTitle(),true);
	}
	@AfterTest
	public void CloseBrowser()	{
		driver.quit();
	}
}
