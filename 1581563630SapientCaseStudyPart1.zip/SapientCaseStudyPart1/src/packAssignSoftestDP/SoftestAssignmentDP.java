package packAssignSoftestDP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SoftestAssignmentDP extends OpenCloseBrowser
{
	
	@BeforeMethod
	public void Home()
	{
		OpenHomePage();		
	}
	
	@Test(dataProvider="Softest",dataProviderClass=MyDataproviders.class)
	public void TC_Softest_Login(String user,String pwd,String verify,String page,String type) 
	{
		System.out.println("===================");
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("textfield")).sendKeys(user);
		driver.findElement(By.id("textfield2")).sendKeys(pwd);
		driver.findElement(By.id("submit")).click();
		Reporter.log("Submit login form : UserName : "+user + "  ,  Password: " + pwd,true);
		Reporter.log("Test Case Type is :  " + type,true);
		Assert.assertTrue(driver.getCurrentUrl().contains(page),"Login -  " + type);
		Reporter.log("Opened Page " + page,true);
		if(type.equalsIgnoreCase("valid"))
		{
			WebElement msg=driver.findElement(By.xpath("//td[@class='menu_link2']/p[8]"));
			Assert.assertTrue(msg.getText().contains(verify), "UserName displayed on Student page");
			Reporter.log("Message Displayed " + verify,true);
			driver.findElement(By.linkText("Sign Out")).click();			
		}	
		else
		{
			WebElement msg=driver.findElement(By.className("style1"));
			Assert.assertTrue(msg.getText().contains(verify),"Failed to Login message");
			Reporter.log("Message Displayed " + verify,true);
		}		
	}	
}
