//Count time sheet Time Card History
package com;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class AssesmentQ2 {

public WebDriver driver;
public String fn,title,url;
public WebDriverWait wait;
ReadConfig config;

String uname=""; //Enter UserName
String pass=""; //Enter Password


@BeforeTest
public void openBrowserFirefox()
{
   config=new ReadConfig();
   System.setProperty("webdriver.gecko.driver", config.getFirefoxDriverPath());
   driver=new FirefoxDriver();
   driver.manage().window().maximize();
   driver.manage().timeouts().implicitlyWait(config.getImplicitlyWait(), TimeUnit.SECONDS);
   wait=new WebDriverWait(driver,config.getExplicitWait()); 
   driver.get("https://timetracking.sapient.com/");
   title=driver.getTitle();
   System.out.println("Homepage title is: "+title);
}

@Test
public void timeTrack() throws Exception
{
	Thread.sleep(1000);
	driver.findElement(By.id("userNameInput")).sendKeys(uname);
	driver.findElement(By.id("passwordInput")).sendKeys(pass);
	Thread.sleep(1000);
	driver.findElement(By.id("submitButton")).click();
	Thread.sleep(1000);
	driver.findElement(By.linkText("Time Card History")).click();
	Thread.sleep(2000);
	WebElement table = driver.findElement(By.id("MainContent_gdvTimeCardHistory"));
	List <WebElement> rows = table.findElements(By.tagName("tr"));
	System.out.println("Number of entries : "+(rows.size()-1));
}


@AfterTest
public void closeBrowser()
{
driver.quit();
}
}

